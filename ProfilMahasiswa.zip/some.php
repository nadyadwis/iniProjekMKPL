<?php
	echo "Teks ini dihasilkan oleh web service dari: ";
	echo $_POST['name'] . " di " . $_POST['location'];
?>